package com.example.itam.config;
import org.springframework.context.annotation.*;
import java.util.concurrent.*;

@Configuration
public class AsyncConfig {
@Bean
public Executor executor() {
return Executors.newFixedThreadPool(10);
}
}
