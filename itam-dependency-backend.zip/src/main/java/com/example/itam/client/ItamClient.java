package com.example.itam.client;
import com.example.itam.model.ItamDetails;
import org.springframework.stereotype.Component;

@Component
public class ItamClient {
public ItamDetails getItamDetails(String itamId) {
ItamDetails d = new ItamDetails();
d.setItamId(itamId);
d.setDescription("Sample description for " + itamId);
return d;
}
}
