package com.example.itam.controller;

import com.example.itam.model.EnrichedNode;
import com.example.itam.service.DependencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DependencyController {

@Autowired
private DependencyService service;

@PostMapping("/enrich")
public List<EnrichedNode> enrich(@RequestBody List<String> ids) {
return service.enrichAll(ids);
}
}
