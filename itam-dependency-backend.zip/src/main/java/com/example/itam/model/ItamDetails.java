package com.example.itam.model;
import lombok.Data;

@Data
public class ItamDetails {
private String itamId;
private String description;
}
