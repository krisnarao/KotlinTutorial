package com.example.itam.model;
import lombok.*;

@Data
@Builder
public class EnrichedNode {
private String itamId;
private String description;
private String manifest;
}
