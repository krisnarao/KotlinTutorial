package com.example.itam.service;

import com.example.itam.client.ItamClient;
import com.example.itam.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Service
public class DependencyService {

@Autowired
private ItamClient itamClient;

@Autowired
private GitManifestService manifestService;

@Autowired
private Executor executor;

public EnrichedNode enrich(String itamId) {
try {
CompletableFuture<ItamDetails> itamFuture =
CompletableFuture.supplyAsync(() -> itamClient.getItamDetails(itamId), executor);

CompletableFuture<String> manifestFuture =
CompletableFuture.supplyAsync(() -> manifestService.getManifest(itamId), executor);

CompletableFuture.allOf(itamFuture, manifestFuture).join();

return EnrichedNode.builder()
.itamId(itamId)
.description(itamFuture.get().getDescription())
.manifest(manifestFuture.get())
.build();

} catch (Exception e) {
throw new RuntimeException(e);
}
}

public List<EnrichedNode> enrichAll(List<String> ids) {
return ids.stream()
.map(id -> CompletableFuture.supplyAsync(() -> enrich(id), executor))
.map(CompletableFuture::join)
.collect(Collectors.toList());
}
}
