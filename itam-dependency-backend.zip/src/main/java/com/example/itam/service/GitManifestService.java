package com.example.itam.service;
import org.eclipse.jgit.api.Git;
import org.springframework.stereotype.Service;
import java.io.File;
import java.nio.file.*;

@Service
public class GitManifestService {

private static final String REPO_URL = "https://github.com/sample/repo.git";
private static final String LOCAL_DIR = "/tmp/repo";

public String getManifest(String itamId) {
try {
File dir = new File(LOCAL_DIR);

if (!dir.exists()) {
Git.cloneRepository().setURI(REPO_URL).setDirectory(dir).call();
} else {
Git.open(dir).pull().call();
}

Path path = Path.of(LOCAL_DIR + "/manifests/" + itamId + ".yaml");

if (Files.exists(path)) {
return Files.readString(path);
}
} catch (Exception e) {
e.printStackTrace();
}
return "NOT_FOUND";
}
}
