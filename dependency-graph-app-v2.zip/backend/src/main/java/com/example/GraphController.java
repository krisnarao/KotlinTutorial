
package com.example;

import org.springframework.web.bind.annotation.*;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.util.*;

@RestController
@RequestMapping("/api/graph")
public class GraphController {

    private final ItamServiceClient client = new ItamServiceClient();

    @GetMapping
    public Map<String, Object> getGraph() throws Exception {

        Yaml yaml = new Yaml();
        Map<String, Object> data = yaml.load(new FileInputStream("manifest.yaml"));

        List<Map<String, Object>> rules =
                (List<Map<String, Object>>) data.get("fwrules");

        Map<String, Map<String, Object>> nodes = new HashMap<>();
        List<Map<String, String>> links = new ArrayList<>();

        for (Map<String, Object> rule : rules) {
            String src = String.valueOf(rule.get("sourceitam"));
            String dst = String.valueOf(rule.get("destinationitam"));

            nodes.putIfAbsent(src, Map.of("id", src, "name", src));

            if (!nodes.containsKey(dst)) {
                ItamDetails d = client.getDetails(dst);
                nodes.put(dst, Map.of(
                        "id", dst,
                        "name", d != null ? d.name : dst,
                        "criticality", d != null ? d.criticality : "UNKNOWN"
                ));
            }

            links.add(Map.of("source", src, "target", dst));
        }

        Map<String, Object> res = new HashMap<>();
        res.put("nodes", nodes.values());
        res.put("links", links);

        return res;
    }
}
