
package com.example;

public class ItamDetails {
    public String itamId;
    public String name;
    public String owner;
    public String criticality;
}
