
package com.example;

import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

public class ItamServiceClient {

    private static final String API_URL = "https://api.company.com/itam/details";
    private static final String JWT_TOKEN = "REPLACE_WITH_REAL_TOKEN";

    private final RestTemplate restTemplate = new RestTemplate();

    public ItamDetails getDetails(String itamId) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(JWT_TOKEN);

        String body = "{\"itamId\": \"" + itamId + "\"}";
        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        ResponseEntity<ItamDetails> response =
            restTemplate.exchange(API_URL, HttpMethod.POST, entity, ItamDetails.class);

        return response.getBody();
    }
}
