
import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";

export default function App() {
  const ref = useRef();
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/api/graph")
      .then(res => res.json())
      .then(data => draw(data));
  }, []);

  const draw = ({ nodes, links }) => {
    const svg = d3.select(ref.current);
    svg.selectAll("*").remove();

    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id(d => d.id))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(400, 300));

    const link = svg.append("g")
      .selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke", "#aaa");

    const node = svg.append("g")
      .selectAll("circle")
      .data(nodes)
      .enter().append("circle")
      .attr("r", 8)
      .attr("fill", "blue")
      .on("click", (_, d) => highlight(d.id));

    const label = svg.append("g")
      .selectAll("text")
      .data(nodes)
      .enter().append("text")
      .text(d => d.name || d.id)
      .attr("font-size", 10);

    simulation.on("tick", () => {
      link.attr("x1", d => d.source.x)
          .attr("y1", d => d.source.y)
          .attr("x2", d => d.target.x)
          .attr("y2", d => d.target.y);

      node.attr("cx", d => d.x)
          .attr("cy", d => d.y);

      label.attr("x", d => d.x + 10)
           .attr("y", d => d.y);
    });

    function highlight(id) {
      link.attr("stroke", l => l.source.id === id ? "red" : "#aaa");
    }
  };

  return (
    <div>
      <input
        placeholder="Search ITAM"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      <svg ref={ref} width={800} height={600}></svg>
    </div>
  );
}
