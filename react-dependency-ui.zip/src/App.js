import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";

export default function App() {
  const svgRef = useRef();
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch("http://localhost:8080/api/graph")
      .then(res => res.json())
      .then(setData);
  }, []);

  useEffect(() => {
    if (data) drawGraph(data);
  }, [data]);

  const drawGraph = ({ nodes, links }) => {
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = window.innerWidth;
    const height = window.innerHeight;

    const g = svg.append("g");

    svg.call(d3.zoom().on("zoom", (event) => {
      g.attr("transform", event.transform);
    }));

    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id(d => d.id).distance(150))
      .force("charge", d3.forceManyBody().strength(-500))
      .force("center", d3.forceCenter(width/2, height/2))
      .force("collision", d3.forceCollide().radius(40));

    const link = g.selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke", "#aaa");

    const node = g.selectAll("circle")
      .data(nodes)
      .enter().append("circle")
      .attr("r", 10)
      .attr("fill", "steelblue");

    simulation.on("tick", () => {
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);

      node
        .attr("cx", d => d.x)
        .attr("cy", d => d.y);
    });
  };

  return <svg ref={svgRef} width="100%" height="100vh"></svg>;
}
