package com.vaultguardian.ai.dto;

public class SecretRequest {
}
