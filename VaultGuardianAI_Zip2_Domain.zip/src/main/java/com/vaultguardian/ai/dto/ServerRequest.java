package com.vaultguardian.ai.dto;

public class ServerRequest {
}
