package com.vaultguardian.ai.enums;

public enum Criticality { LOW, MEDIUM, HIGH, CRITICAL }