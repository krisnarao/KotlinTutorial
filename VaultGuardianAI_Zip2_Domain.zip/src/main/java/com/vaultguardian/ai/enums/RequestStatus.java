package com.vaultguardian.ai.enums;

public enum RequestStatus { PENDING, APPROVED, REJECTED }