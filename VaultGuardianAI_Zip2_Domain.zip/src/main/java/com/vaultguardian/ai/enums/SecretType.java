package com.vaultguardian.ai.enums;

public enum SecretType { PASSWORD, TOKEN, CERTIFICATE, KEY }