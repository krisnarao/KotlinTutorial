package com.vaultguardian.ai.enums;

public enum ApprovalStatus { PENDING, APPROVED, REJECTED }