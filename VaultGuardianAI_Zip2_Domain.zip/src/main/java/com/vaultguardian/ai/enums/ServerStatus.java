package com.vaultguardian.ai.enums;

public enum ServerStatus { UP, DOWN, MAINTENANCE }