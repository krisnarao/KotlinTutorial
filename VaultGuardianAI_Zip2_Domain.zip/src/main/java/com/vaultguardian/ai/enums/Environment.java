package com.vaultguardian.ai.enums;

public enum Environment { DEV, SIT, UAT, PROD }