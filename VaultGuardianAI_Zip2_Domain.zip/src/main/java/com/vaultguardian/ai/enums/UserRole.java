package com.vaultguardian.ai.enums;

public enum UserRole { ADMIN, ENGINEER, SECURITY, PLATFORM_OWNER, AUDITOR }