package com.vaultguardian.ai.entity;

public class BreakglassRequest {
}
