package com.vaultguardian.ai.entity;

public class Role {
}
