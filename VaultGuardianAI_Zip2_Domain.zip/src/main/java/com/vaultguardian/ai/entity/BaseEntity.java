package com.vaultguardian.ai.entity;

public class BaseEntity {
}
