package com.vaultguardian.ai.entity;

public class User {
}
