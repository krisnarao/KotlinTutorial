package com.vaultguardian.ai.entity;

public class Approval {
}
