package com.vaultguardian.ai.repository;

public interface ServerRepository {
}
